#include<stdio.h>
#include<stdlib.h>

long f(int n) {
      if (n == 0 || n ==1) {
         return 1;
      }
      else
      return f(n - 1) + f(n - 2);//ǰһ��ͼӺ�һ���
   }

int main(){
	int n;
	printf("����n��\n");
	scanf("%d",&n);
	float g = (float)(f(n))/(float)(f(n+1));
	printf("float g = %.8f\n",g);
	double d = (double)(f(n))/(double)(f(n+1));
	printf("double g = %8lf\n",d);
	
}
