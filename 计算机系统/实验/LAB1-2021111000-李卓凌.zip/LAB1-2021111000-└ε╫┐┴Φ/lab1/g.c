#include<stdio.h>
int main(){
	double fib[102] = {0};//��ʼ��
	fib[0] = 1;
	fib[1] = 1;
	long long n ,i;
	printf("Input n\n");
	scanf("%lld",&n);
	for(i = 2; i <= n; i++)
		fib[i] = fib[i-1]+fib[i-2];
	double g = (fib[n-1])/(fib[n]);
	printf("�Ż���Ļƽ�ָ�ֵ��%.8lf",g);
	return 0;
}
