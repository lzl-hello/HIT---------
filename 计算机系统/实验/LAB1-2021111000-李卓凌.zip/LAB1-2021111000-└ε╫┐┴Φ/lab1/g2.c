#include<stdio.h>
#include<stdlib.h>
long fib[102] = {0};
long f(int n) {
	fib[0] = 1;
	fib[1] = 1;
	int i = 2;
	if(n == 1 || n ==0){
		return 1;
	}
	for(i = 2;i<=n;i++){
		fib[i] = fib[i-1]+fib[i-2];
	}
	return fib[n];

}
int main(){
	int n;
	printf("����n��\n");
	scanf("%d",&n);
	float g = (float)(f(n))/(float)(f(n+1));
	printf("float g = %.8f\n",g);
	double d = (double)(f(n))/(double)(f(n+1));
	printf("double g = %8lf\n",d);
	
}



