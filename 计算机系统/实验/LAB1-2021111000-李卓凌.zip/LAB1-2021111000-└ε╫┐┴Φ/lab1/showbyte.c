#include<stdio.h>
#include<stdlib.h>
int main()
{
    FILE *fp =NULL;
    fp= fopen("hello.c","r");
    int size;
    if( fp == NULL)
        return 0;
    else
    {
        fseek(fp,0,SEEK_END);
        size = ftell(fp);
        rewind(fp);
        char *buf = malloc(size*sizeof(char));
        fread(buf,size,1,fp);
        fclose(fp);
        int asc[size];
        for (int i = 0; i < size; ++i) {
            asc[i]=buf[i];
        }
        int count= 0;
        int j=0;
        for (int i = 0; i < size; ++i) {
            if(asc[i] ==10)
            {
                printf("\\n\t");
            }
            else if(asc[i]==9)
            {
                printf("\\t\t");
            }
            else if(asc[i]==32)
            {
                printf(" \t");
            }
            else
            {
                printf("%c\t", asc[i]);
            }
            count++;
            if(count%16 ==0) {
                int count1 = 0;
                printf("\n");
                for(j;j<size;j++)
                {
                    printf("%d\t",asc[j]);
                    count1++;
                    if(count1%16 ==0)
                    {
                        printf("\n");
                        break;
                    }
                }
                j++;
            }
            else if(count ==size)
            {
                printf("\n");
                for(j;j<size;j++) {
                    printf("%d\t", asc[j]);
                }
            }
        }
    }
}
