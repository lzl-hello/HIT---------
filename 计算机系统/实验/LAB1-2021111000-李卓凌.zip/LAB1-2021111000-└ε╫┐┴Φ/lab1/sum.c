#include<stdio.h>
#include<stdlib.h>
int sum(int a[],unsigned len){
 	int i,sum = 0;
 	for(int i=0;i<=len-1;i++){
	 	sum+=a[i];
	}
	return sum;
}
int main(){
 	int a[5] = {0,1,2,3,4};
 	int result = sum(a,0);
 	printf("sum = %d",result);
 	
}
